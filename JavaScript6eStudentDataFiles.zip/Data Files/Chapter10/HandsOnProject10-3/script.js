/*  JavaScript 6th Edition
    Chapter 10
    Hands-on Project 10-3

    Author: 
    Date:   

    Filename: script.js
*/

"use strict";

